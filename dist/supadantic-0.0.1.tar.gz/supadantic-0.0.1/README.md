# supadantic
Pydantic + Supabase = &lt;3
